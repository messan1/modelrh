export interface Qualite{
    ordre:number,
    code:string
}