import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


//Importation





@NgModule({
  declarations: [],
  imports: [
    CommonModule,

  ]
})
export class TemplateHomeModule { }
